#!/bin/bash
set -e -v
javac *.java
java Qlearning
