#!/bin/bash
set -e -x
echo "Building..."
javac *.java
echo "To execute, do:"
echo "java Viz"

