#!/bin/bash
javac *.java
#Black White depths
#java ChessState 3 5
#java ChessState 5 5
#java ChessState 0 0
#java ChessState 5 0
#java ChessState 0 5